package com.example.chess;

public class GameMaster {
    GameController gameController;
    GameUI gameUI;

    Square selectedSquare = null;

    int humanColor  = Piece.whiteColor();;

    public GameMaster(GameController gameController, GameUI gameUI) {
        this.gameController = gameController;
        this.gameUI = gameUI;
    }

    /**
     * @todo create an action Interface that both controller and UI should implement.
     *
     * @param squareIndex the index of the square of the virtual board
     */
    public void actionHandler(int squareIndex) {
        Square clickedSquare = gameController.getBoard()[squareIndex];
        if (selectedSquare == null) {
            if (gameController.getPieceColor(squareIndex) == humanColor) {
                selectedSquare = clickedSquare;
                gameController.selectPiece(selectedSquare);
                gameUI.selectPiece(gameController.getHighlightedSquares());
            }
        }
        else {
            if (gameController.getPieceColor(squareIndex) == humanColor) {
                if (selectedSquare != clickedSquare) {
                    selectedSquare = clickedSquare;
                    selectedSquare = gameController.getBoard()[squareIndex];
                    gameController.selectPiece(selectedSquare);
                    gameUI.selectPiece(gameController.getHighlightedSquares());
                }
                else {
                    /**
                     * @todo when I end the action, I dont want to iterate over the whole
                     * board in order to remove the highlighted squares. I should create a
                     * function dat undo's only the squares.
                     */
                    gameController.endAction();
                    gameUI.endAction();
                    selectedSquare = null;
                }
            }
            else {
                Move wantedMove = new Move(selectedSquare.getSquareIndex(), clickedSquare.getSquareIndex());
                if (gameController.moveValidator(wantedMove)) {
                    gameController.executeMove(clickedSquare);
                    gameUI.drawPiecesOnBoard(gameController.getBoard());
                }
                else {
                    gameController.endAction();
                }
                gameUI.endAction();
                selectedSquare = null;
            }
        }
    }

    /**
     * This method will rotate the board 180 degrees. The players color is kept. This allows
     * the player to play from any side(top or bottom). The state of the game is preserved.
     */
    public void changeSide() {
         /*
        When the board is rotated 180 degrees, the underlying representation of the game
        is not affected. The only things that change are the visuals. Since the views (the squares
         of the board) are never moved on the screen, 2 actions are required:
        1) Reverse the order in the list of views. The pieces are placed on the board from white's
        perspective. Since the view board does't actually move, the placement of the pieces should
        start from the other side of the board, thus the reverse of the order.
        2) Change the indices that identifies a view with it's place on the board. The views are
        numbered from white's perspective. Since the players changed sides, a new numbering is needed.
        This is acquired by revering the existing indices.
         */
        gameUI.changeIndices();
        gameUI.reverseViewOrder();

        gameUI.drawPiecesOnBoard(gameController.getBoard());
        if (selectedSquare != null) {
            // Since the map was rotated, reselect the piece that was selected prior to
            // the rotation.
            gameUI.selectPiece(gameController.getHighlightedSquares());
        }
    }
    public void StartGame() {
        gameController.loadGameStateFromFen();
        gameUI.colorBoard();
        gameUI.drawPiecesOnBoard(gameController.getBoard());
    }

//    public GameController getGameControllerC() {
//        return gameControllerC;
//    }
//
//    public void setGameControllerC(GameController gameControllerC) {
//        this.gameControllerC = gameControllerC;
//    }
//
//    public GameUI getGameUIUI() {
//        return gameUIUI;
//    }
//
//    public void setGameUIUI(GameUI gameUIUI) {
//        this.gameUIUI = gameUIUI;
//    }
}
