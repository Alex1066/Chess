package com.example.chess;

import android.annotation.SuppressLint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


class PlayerTurn {
    public static final int black = 1;
    public static final int white = 2;

    public static int oppositePlayerColor(int color) {
        if (color == black) {
            return white;
        }
        return black;
    }
}

/**
 * This is the game class responsible for controlling only the information that describes
 * the state of the game.
 */
public class GameController {
    private String FEN;

    private int currentPlayer;
    private int humanColor;


    private Map<Character, Integer> pieceFromSymbol;
    private Map<Integer, String> symbolFromPiece;


    private Square selectedSquare;

    public Square[] getBoard() { return board; }


    private Square[] board = new Square[64];

    // The offsets of the top,bottom, right, left, top-right, top-left, bottom-right,
    // bottom-left directions respectively.
    private static final int[] directionOffset = {8,-8,1,-1,9,7,-7,-9};
    private static final int[][] squaresToTheEdge = new int[64][8];


    private List<Move> availableMoves;
    private List<Integer> highlightedSquares;


    public List<Integer> getHighlightedSquares() {
        return highlightedSquares;
    }

    /**
     * The constructor of the class.
     * @todo maybe add an repository for a square. and made CRUD methods
     *
     * @param FEN a string representation of the current state of the game
     */
    public GameController(String FEN){
        this.FEN = FEN;

        currentPlayer = PlayerTurn.white;
        humanColor = Piece.pieceColor(Piece.white);

        for (int i = 0; i < 64; i++) {
            board[i] = new Square(i,0);
        }
        pieceFromSymbol = new HashMap<>();
        symbolFromPiece = new HashMap<>();
        availableMoves = new ArrayList<>();
        highlightedSquares = new ArrayList<>();


        fillDictionaries();
        precomputedDistanceData();
    }

    /**
     * This method creates dictionaries in order to have a quick translation between piece
     * representation as a character in FEN and as a integer on the board.
     */
    public void fillDictionaries() {
        pieceFromSymbol.put('k', Piece.black+Piece.king);
        pieceFromSymbol.put('q', Piece.black+Piece.queen);
        pieceFromSymbol.put('r', Piece.black+Piece.rook);
        pieceFromSymbol.put('b', Piece.black+Piece.bishop);
        pieceFromSymbol.put('n', Piece.black+Piece.knight);
        pieceFromSymbol.put('p', Piece.black+Piece.pawn);
        pieceFromSymbol.put('K', Piece.white+Piece.king);
        pieceFromSymbol.put('Q', Piece.white+Piece.queen);
        pieceFromSymbol.put('R', Piece.white+Piece.rook);
        pieceFromSymbol.put('B', Piece.white+Piece.bishop);
        pieceFromSymbol.put('N', Piece.white+Piece.knight);
        pieceFromSymbol.put('P', Piece.white+Piece.pawn);

        symbolFromPiece.put(Piece.black+Piece.king, "k");
        symbolFromPiece.put(Piece.black+Piece.queen, "q");
        symbolFromPiece.put(Piece.black+Piece.rook, "r");
        symbolFromPiece.put(Piece.black+Piece.bishop, "b");
        symbolFromPiece.put(Piece.black+Piece.knight, "n");
        symbolFromPiece.put(Piece.black+Piece.pawn, "p");
        symbolFromPiece.put(Piece.white+Piece.king, "K");
        symbolFromPiece.put(Piece.white+Piece.queen, "Q");
        symbolFromPiece.put(Piece.white+Piece.rook, "R");
        symbolFromPiece.put(Piece.white+Piece.bishop, "B");
        symbolFromPiece.put(Piece.white+Piece.knight, "N");
        symbolFromPiece.put(Piece.white+Piece.pawn, "P");
    }

    /**
     * This method will computes and store the distance of each square from the edges, in all 8
     * directions: top, bottom, right, left, top-right, top-left, bottom-right, bottom-left.
     * This will help when generating the valid moves for a piece.
     */
    public void precomputedDistanceData() {
        for (int rank = 0; rank < 8; rank++) {
            for (int file = 0; file < 8; file++) {
                int topDirection = 7 - rank;
                int bottomDirection = rank;
                int rightDirection = 7 - file;
                int leftDirection = file;
                int topRightDirection = Math.min(topDirection, rightDirection);
                int topLeftDirection = Math.min(topDirection, leftDirection);
                int bottomRightDirection = Math.min(bottomDirection, rightDirection);
                int bottomLeftDirection = Math.min(bottomDirection, leftDirection);

                int squareIndex = rank * 8 + file;

                squaresToTheEdge[squareIndex][0] = topDirection;
                squaresToTheEdge[squareIndex][1] = bottomDirection;
                squaresToTheEdge[squareIndex][2] = rightDirection;
                squaresToTheEdge[squareIndex][3] = leftDirection;
                squaresToTheEdge[squareIndex][4] = topRightDirection;
                squaresToTheEdge[squareIndex][5] = topLeftDirection;
                squaresToTheEdge[squareIndex][6] = bottomRightDirection;
                squaresToTheEdge[squareIndex][7] = bottomLeftDirection;
            }
        }
    }


    /**
     * This method will load the positions of the pieces on the board according to the fen.
     * Fen is a string that contains all the information needed for initializing a game in any
     * state (after any number of moves).
     */
    public void loadGameStateFromFen() {
        int file = 0, rank = 7, squareIndex;
        String gameState = FEN.split(" ")[0];

        for (int i = 0; i < gameState.length(); i++) {
            char symbol = gameState.charAt(i);
            if (symbol == '/') {
                rank -= 1;
                file = 0;
            }
            else {
                if (Character.isDigit(symbol)) {
                    file += Character.getNumericValue(symbol);
                } else {
                    squareIndex = (rank) * 8 + file;
                    Integer checkIfExists = pieceFromSymbol.get(symbol);
                    int piece = checkIfExists != null ? checkIfExists : 0;
                    board[squareIndex] = new Square(squareIndex, piece);
                    file++;
                }
            }
        }
    }

    /**
     * After a move is made the FEN (which is a string representation of the state of the game) is
     * updated.
     */
    public void updateFen() {
        int numberEmptySquares = 0;
        StringBuilder positionsFen = new StringBuilder();
        int piece;
        for (int rank = 7; rank >= 0; rank --) {
            for (int file = 0; file < 8; file ++) {
                piece = board[rank * 8 + file].getPiece();
                if (piece == Piece.empty) {
                    numberEmptySquares ++;
                }
                else {
                    if (numberEmptySquares != 0) {
                        positionsFen.append(numberEmptySquares);
                        numberEmptySquares = 0;
                    }
                    positionsFen.append(symbolFromPiece.get(piece));
                }
            }
            if (numberEmptySquares != 0) {
                positionsFen.append(numberEmptySquares);
                numberEmptySquares = 0;
            }
            if (rank != 0) {
                positionsFen.append("/");
            }
        }
        FEN = FEN.replaceAll(FEN.split(" ")[0], positionsFen.toString());
    }

    public void changeHumanColor() {
        humanColor = PlayerTurn.oppositePlayerColor(humanColor);
    }

    public int getPieceColor(int index) {
        return Piece.pieceColor(board[index].getPiece());
    }

    public void endAction() {
        selectedSquare = null;
        availableMoves.clear();
        highlightedSquares.clear();
    }

    /**
     * @// TODO: 2/28/2021
     * Here computer move should be added after endAction();
     */
    public void executeMove(Square clickedSquare) {
        board[clickedSquare.getSquareIndex()].setPiece(selectedSquare.getPiece());
        board[selectedSquare.getSquareIndex()].setPiece(Piece.empty);
        endAction();
        updateFen();
    }

    public boolean moveValidator(Move moveToValidate){
        for(Move m: availableMoves) {
            if (m.equals(moveToValidate)) {
                return true;
            }
        }
        return false;
    }

    public void selectPiece(Square clickedSquare) {
        endAction();
        selectedSquare = clickedSquare;
        generateAvailableMoves();
        highlightedSquares.add(selectedSquare.getSquareIndex());
    }

    /**
     * After one piece was selected, this method will be called to compute the available moves for
     * that piece.
     * @// TODO: 2/28/2021
     * Instead of generating moves only for the selected piece it will be better to generate prior
     * to piece selection everything. Therefore everything will be computed while the player is
     * thinking, only the validation of move will be done after player input.
     */
    @SuppressLint("ResourceType")
    public void generateAvailableMoves() {
        if (Piece.isSlidingPiece(selectedSquare.getPiece())){
            getAvailableMovesForSlidingPieces(selectedSquare);
        }
        for (Move e: availableMoves) {
            highlightedSquares.add(e.targetSquare);
        }
    }

    /**
     * This method is called to compute the available moves for pieces that slide on the board
     * i.e the rook, the bishop and the queen.
     *
     * @param square the square of the board for which we want to compute the available moves. This
     *               variable holds the index of the board square and the piece situated on the square.
     */
    public void getAvailableMovesForSlidingPieces(Square square) {
        // Rook can walk only int the first 4 directions.
        // Bishop can walk only in the last 4 directions.
        // Queen is unrestricted.
        int startDirection = Piece.isPieceType(square.getPiece(), Piece.bishop) ?  4 :  0;
        int endDirection = Piece.isPieceType(square.getPiece(), Piece.rook) ?  4 :  8;
        for (int direction = startDirection; direction < endDirection; direction ++) {
            for (int i = 0; i < squaresToTheEdge[square.getSquareIndex()][direction]; i++) {
                int targetSquareIndex = square.getSquareIndex() + directionOffset[direction] * (i+1);
                int targetPiece = board[targetSquareIndex].getPiece();

                // If it encounters a friendly piece then it cant move further in this direction.
                if (Piece.pieceColor(targetPiece) == currentPlayer) {
                    break;
                }
                availableMoves.add(new Move(square.getSquareIndex(), targetSquareIndex));

                // If the square had an enemy piece on it, then no other moves are available in
                // this direction.
                if (Piece.pieceColor(targetPiece) == PlayerTurn.oppositePlayerColor(currentPlayer)){
                    break;
                }
            }
        }

    }

}
