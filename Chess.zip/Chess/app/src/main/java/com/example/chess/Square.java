package com.example.chess;

public class Square {

    private int squareIndex;
    private int piece;

    public Square(int squareIndex, int piece) {
        this.squareIndex = squareIndex;
        this.piece = piece;
    }

    public int getSquareIndex() {
        return squareIndex;
    }

    public void setSquareIndex(int squareIndex) {
        this.squareIndex = squareIndex;
    }

    public int getPiece() {
        return piece;
    }

    public void setPiece(int piece) {
        this.piece = piece;
    }
}
