package com.example.chess;

import android.graphics.drawable.Drawable;

import java.util.List;
import java.util.Map;


class SquareColor {
    public static final int darkSquare = 0;
    public static final int lightSquare = 1;

    public static int findColorFromIndex(int index){
        int rank = index / 8;
        int file = index % 8;
        if (rank % 2 == file % 2) {
            return darkSquare;
        }
        return lightSquare;
    }
}


public class GameUI {

    private CustomImageView[] boardSquares;
    private ColorTheme colorTheme;
    private Map<Integer, Drawable> pieces;

    /**
     * @// TODO: 2/28/2021
     * On this matter a good thing to be implemented is to change the asset from background image
     * to foreground image. This way I can add as a background to the piece some sort of sign that
     * tells that this piece can be attacked by the selected piece.
     * @param boardSquares the list of the views displayed on the screen
     * @param colorTheme all the information about the color palette of the visuals on the board
     * @param pieces the images of the chess pieces
     */
    public GameUI(CustomImageView[] boardSquares, ColorTheme colorTheme, Map<Integer, Drawable> pieces) {
        this.boardSquares = boardSquares;
        this.colorTheme = colorTheme;
        this.pieces = pieces;
    }


    public void selectPiece(List<Integer> squaresToHighlight) {
        endAction();
        for(Integer square: squaresToHighlight) {
            if (SquareColor.findColorFromIndex(boardSquares[square].getSquareIndex()) == SquareColor.lightSquare) {
                boardSquares[square].setBackgroundColor(colorTheme.getActiveLightSquare());
            }
            else {
                boardSquares[square].setBackgroundColor(colorTheme.getActiveDarkSquare());
            }
        }
    }

    public void endAction() {
        colorBoard();
    }


    /**
     * This method changes the colors to the original. It is used to remove all the highlighting
     * that was done.
     * @// TODO: 2/28/2021
     * This function may be removed. This one recolors every single square of the board which is too much.
     * This may remain only if I want to add multiple color-sets as option for the board.
     * The squares that should be highlighted are the initial and target square after a move, and
     * initial square during the move(when piece is selected). To remove the highlight will create
     * a separate function that doesn't iterate all the board.
     */
    public void colorBoard() {
        for (int i = 0; i < boardSquares.length/2; i++) {
            if (SquareColor.findColorFromIndex(i) == SquareColor.lightSquare) {
                boardSquares[i].setBackgroundColor(colorTheme.getLightSquare());
                boardSquares[boardSquares.length - i - 1].setBackgroundColor(colorTheme.getLightSquare());
            }
            else {
                boardSquares[i].setBackgroundColor(colorTheme.getDarkSquare());
                boardSquares[boardSquares.length - i - 1].setBackgroundColor(colorTheme.getDarkSquare());
            }
        }
    }

    /**
     * This method will load the assets of the pieces on the squares, after the positions were set.
     *
     * @param boardData a list that contains the piece-codes for each square
     */
    public void drawPiecesOnBoard(Square[] boardData) {
        for (int index = 0; index < boardData.length; index++){
            boardSquares[index].setImageDrawable(pieces.get(boardData[index].getPiece()));
        }
    }
    /**
     * @// TODO: 2/28/2021
     * When the game is complete this should be removed as I don't want to show like this the possible
     * moves for the selected piece. If I want to show that somehow, I must create another function
     * to handel it and do what I mentioned in the comment on the top of the class.
     *
     * @param squaresToHighlight a list of possible moves that need to be shown so the player knows
     *                           where he can move the piece
     */
    public void highlightSquares(List<Integer> squaresToHighlight) {
        for(Integer square: squaresToHighlight) {
            if (SquareColor.findColorFromIndex(boardSquares[square].getSquareIndex()) == SquareColor.lightSquare) {
                boardSquares[square].setBackgroundColor(colorTheme.getActiveLightSquare());
            }
            else {
                boardSquares[square].setBackgroundColor(colorTheme.getActiveDarkSquare());
            }
        }
    }

    public void undoHighlightedSquares(List<Integer> highlightedSquares) {
        for(Integer square: highlightedSquares) {
            if (SquareColor.findColorFromIndex(boardSquares[square].getSquareIndex()) == SquareColor.lightSquare) {
                boardSquares[square].setBackgroundColor(colorTheme.getLightSquare());
            }
            else {
                boardSquares[square].setBackgroundColor(colorTheme.getDarkSquare());
            }
        }
    }

    public void changeIndices() {
        for (int i = 0; i < boardSquares.length/2; i++) {
            int aux = boardSquares[i].getSquareIndex();
            boardSquares[i].setSquareIndex(boardSquares[boardSquares.length - i - 1].getSquareIndex());
            boardSquares[boardSquares.length - i - 1].setSquareIndex(aux);
        }
    }
    public void reverseViewOrder() {
        for (int i = 0; i < boardSquares.length/2; i++) {
            CustomImageView aux = boardSquares[i];
            boardSquares[i]= boardSquares[boardSquares.length - i - 1];
            boardSquares[boardSquares.length - i - 1] = aux;
        }
    }

    public CustomImageView[] getBoardSquares() { return boardSquares; }

    public ColorTheme getColorTheme() { return colorTheme; }

    public void setColorTheme(ColorTheme boardDesign) { this.colorTheme = colorTheme; }

    public Map<Integer, Drawable> getPieces() { return pieces; }

    public void setPieces(Map<Integer, Drawable> pieces) { this.pieces = pieces; }

}
