package com.example.chess;

public class Move {
    public int initialSquare;
    public int targetSquare;

    public Move(int initialSquareIndex, int targetSquareIndex) {
        initialSquare = initialSquareIndex;
        targetSquare = targetSquareIndex;
    }

    public boolean equals(Move otherMove){
        return (initialSquare == otherMove.initialSquare) &&
                (targetSquare == otherMove.targetSquare);
    }

}
