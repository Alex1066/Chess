package com.example.chess;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private CustomImageView[] squares = new CustomImageView[64];
    public List<Map<Integer, Drawable>> piecesAssets = new ArrayList<>();
    private GameController gc;
    private GameUI gd;
    private GameMaster gm;

    private Map<String, Map<Integer, Drawable>> allSetsOfPieces = new HashMap<>();
    private Map<String, ColorTheme> allBoardThemes = new HashMap<>();

    /**
     * @// TODO: 2/28/2021
     * Instead of passing the context it would be better to just pass a list of drawable
     * containing the chess pieces. This way GameControl will only handle the game logic and
     * nothing more.
     * @// TODO: 3/1/2021
     * The above TO DO was done. But it may be interesting to if I could implement an GameMaster
     * that has as attributes an GameControl and GameDesign. Or create another class GameAbstract
     * or GameNumerical that does what GameControl does now, and the GameControll will have an
     * GameDesign and GameAbstract.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setClickListeners();

        // @todo Perhaps read this from a file or let the user introduce its own fen. This one should
        // be the default value.
        String fenStart = "rnbqkbnr/pppppppp/8/8/8/8/8/RNBQKBNR w KQkq - 0 1";


        loadAssets();
        loadColorThemes();

        gc = new GameController(fenStart);
        gd = new GameUI(squares, allBoardThemes.get("red"), allSetsOfPieces.get("slim"));
        gm = new GameMaster(gc, gd);
        gm.StartGame();

    }
    public void setClickListeners() {
        String viewID;
        int resID;

        for (int index = 0; index < 64; index++) {
            viewID = index < 10 ? "square_0" + index : "square_" + index;
            resID = getResources().getIdentifier(viewID, "id", getPackageName());
            squares[index] = findViewById(resID);
            squares[index].setOnClickListener(this);
        }
        Button bt = findViewById(getResources().getIdentifier("Reset", "id", getPackageName()));
        bt.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view instanceof CustomImageView){
            gm.actionHandler(((CustomImageView) view).getSquareIndex());
        }
        if (view instanceof Button) {
            if (view.getId() == getResources().getIdentifier("Reset", "id", getPackageName())) {
                gm.changeSide();
            }
        }
//        Toast.makeText(this, "Player won", Toast.LENGTH_SHORT).show();
    }

    public void loadColorThemes() {
        int lightSquare = ContextCompat.getColor(this, R.color.blue_theme_light_square);
        int darkSquare = ContextCompat.getColor(this, R.color.blue_theme_dark_square);
        int highlightedLightSquare = ContextCompat.getColor(this, R.color.blue_theme_highlighted_light_square);
        int highlightedDarkSquare = ContextCompat.getColor(this, R.color.blue_theme_highlighted_dark_square);
        allBoardThemes.put("blue", new ColorTheme(lightSquare, darkSquare, highlightedLightSquare, highlightedDarkSquare));

        lightSquare = ContextCompat.getColor(this, R.color.red_theme_light_square);
        darkSquare = ContextCompat.getColor(this, R.color.red_theme_dark_square);
        highlightedLightSquare = ContextCompat.getColor(this, R.color.red_theme_highlighted_light_square);
        highlightedDarkSquare = ContextCompat.getColor(this, R.color.red_theme_highlighted_dark_square);
        allBoardThemes.put("red", new ColorTheme(lightSquare, darkSquare, highlightedLightSquare, highlightedDarkSquare));
    }

    public void loadAssets() {
        Map<Integer, Drawable> pieceSet = new HashMap<>();

        // Classic set of pieces.
        pieceSet.put(Piece.black+Piece.king, ContextCompat.getDrawable(this, R.drawable.classic_black_king));
        pieceSet.put(Piece.black+Piece.queen, ContextCompat.getDrawable(this, R.drawable.classic_black_queen));
        pieceSet.put(Piece.black+Piece.rook, ContextCompat.getDrawable(this, R.drawable.classic_black_rook));
        pieceSet.put(Piece.black+Piece.bishop, ContextCompat.getDrawable(this, R.drawable.classic_black_bishop));
        pieceSet.put(Piece.black+Piece.knight, ContextCompat.getDrawable(this, R.drawable.classic_black_knight));
        pieceSet.put(Piece.black+Piece.pawn, ContextCompat.getDrawable(this, R.drawable.classic_black_pawn));
        pieceSet.put(Piece.white+Piece.king, ContextCompat.getDrawable(this, R.drawable.classic_white_king));
        pieceSet.put(Piece.white+Piece.queen, ContextCompat.getDrawable(this, R.drawable.classic_white_queen));
        pieceSet.put(Piece.white+Piece.rook, ContextCompat.getDrawable(this, R.drawable.classic_white_rook));
        pieceSet.put(Piece.white+Piece.bishop, ContextCompat.getDrawable(this, R.drawable.classic_white_bishop));
        pieceSet.put(Piece.white+Piece.knight, ContextCompat.getDrawable(this, R.drawable.classic_white_knight));
        pieceSet.put(Piece.white+Piece.pawn, ContextCompat.getDrawable(this, R.drawable.classic_white_pawn));
        allSetsOfPieces.put("classic", new HashMap<Integer, Drawable>(pieceSet));
        pieceSet.clear();

        // Slim set of pieces.
        pieceSet.put(Piece.black+Piece.king, ContextCompat.getDrawable(this, R.drawable.slim_black_king));
        pieceSet.put(Piece.black+Piece.queen, ContextCompat.getDrawable(this, R.drawable.slim_black_queen));
        pieceSet.put(Piece.black+Piece.rook, ContextCompat.getDrawable(this, R.drawable.slim_black_rook));
        pieceSet.put(Piece.black+Piece.bishop, ContextCompat.getDrawable(this, R.drawable.slim_black_bishop));
        pieceSet.put(Piece.black+Piece.knight, ContextCompat.getDrawable(this, R.drawable.slim_black_knight));
        pieceSet.put(Piece.black+Piece.pawn, ContextCompat.getDrawable(this, R.drawable.slim_black_pawn));
        pieceSet.put(Piece.white+Piece.king, ContextCompat.getDrawable(this, R.drawable.slim_white_king));
        pieceSet.put(Piece.white+Piece.queen, ContextCompat.getDrawable(this, R.drawable.slim_white_queen));
        pieceSet.put(Piece.white+Piece.rook, ContextCompat.getDrawable(this, R.drawable.slim_white_rook));
        pieceSet.put(Piece.white+Piece.bishop, ContextCompat.getDrawable(this, R.drawable.slim_white_bishop));
        pieceSet.put(Piece.white+Piece.knight, ContextCompat.getDrawable(this, R.drawable.slim_white_knight));
        pieceSet.put(Piece.white+Piece.pawn, ContextCompat.getDrawable(this, R.drawable.slim_white_pawn));
        allSetsOfPieces.put("slim", new HashMap<Integer, Drawable>(pieceSet));
        pieceSet.clear();
    }
}